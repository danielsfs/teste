import csv
import sys
import os
import shutil
import requests

def obter_rodada_atual():
    url = "https://api.cartola.globo.com/mercado/status"
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        rodada_atual = data.get("rodada_atual")
        if rodada_atual is not None:
            return rodada_atual
        else:
            raise ValueError("Campo 'rodada_atual' não encontrado na resposta da API.")
    except Exception as e:
        raise ValueError(f"Erro ao obter número da rodada atual: {str(e)}")

def salvar_csv(texto, caminho, nome_arquivo):
    # Divide o texto em linhas
    linhas = texto.split('\n')
    
    # Define o nome completo do arquivo CSV
    caminho_arquivo = os.path.join(caminho, nome_arquivo)
    
    try:
        # Abre o arquivo CSV para escrita
        with open(caminho_arquivo, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            
            # Escreve cada linha no arquivo CSV
            for linha in linhas:
                # Divide a linha em colunas
                colunas = linha.split(',')
                writer.writerow(colunas)
        
        print(f"Arquivo CSV '{caminho_arquivo}' salvo com sucesso.")
    except Exception as e:
        print(f"Erro ao salvar o arquivo CSV: {str(e)}")

def mover_para_old(caminho_atual, caminho_old):
    try:
        # Se a pasta "Old" não existir, cria
        if not os.path.exists(caminho_old):
            os.makedirs(caminho_old)

        # Mover arquivos para a pasta "Old"
        for filename in os.listdir(caminho_atual):
            src_path = os.path.join(caminho_atual, filename)
            dst_path = os.path.join(caminho_old, filename)
            shutil.move(src_path, dst_path)

        print(f"Arquivos movidos para {caminho_old}.")
    except Exception as e:
        print(f"Erro ao mover arquivos para {caminho_old}: {str(e)}")

if __name__ == "__main__":
    # Verifica se o argumento de texto foi passado
    if len(sys.argv) < 2:
        print("Erro: Nenhum texto foi passado como argumento.")
        sys.exit(1)
    
    # Texto do CSV passado como argumento
    texto_csv = sys.argv[1]

    try:
        # Obter o número da rodada atual
        rodada_atual = obter_rodada_atual()
        nome_arquivo_csv = f"Rodada_{rodada_atual}.csv"

        # Diretório para salvar o arquivo CSV
        dir_importacoes = os.path.join(os.path.dirname(__file__), 'Importações')
        dir_rodada_atual = os.path.join(dir_importacoes, 'Rodada Atual')
        dir_old = os.path.join(dir_importacoes, 'Old')

        # Se a pasta "Rodada Atual" não existir, cria
        if not os.path.exists(dir_rodada_atual):
            os.makedirs(dir_rodada_atual)

        # Mover arquivos existentes para a pasta "Old"
        if os.listdir(dir_rodada_atual):  # Verifica se há arquivos na pasta "Rodada Atual"
            mover_para_old(dir_rodada_atual, dir_old)

        # Salva o novo arquivo CSV na pasta "Rodada Atual"
        salvar_csv(texto_csv, dir_rodada_atual, nome_arquivo_csv)

    except ValueError as ve:
        print(f"Erro: {ve}")
    except Exception as e:
        print(f"Ocorreu um erro inesperado: {str(e)}")
